import { Link, NavLink } from 'react-router-dom';
import { Icon } from '../ui/Icon';
import { useCart } from '../../state/cart';
import { asset, faNumber } from '../../lib/format';
import s from './Header.module.css';

export function Header() {
  const { count } = useCart();

  return (
    <header>
      <nav className={s.nav} aria-label="اصلی">
        {/* Right side (RTL start): brand lockup */}
        <Link to="/" className={s.brand} aria-label="چوکو بار — صفحهٔ اصلی">
          <img src={asset('brand/logo.svg')} alt="چوکو بار" width={153} height={50} className={s.logo} draggable={false} />
          <span className={s.dailyBake}>
            <Icon src="icons/freshness-dot.svg" size={5} />
            پخت روز • هنر سه‌بعدی
          </span>
        </Link>

        {/* Left side (RTL end): shopping controls */}
        <div className={s.controls}>
          <NavLink
            to="/"
            end
            className={({ isActive }) => `${s.link} ${s.collectionLink} ${isActive ? s.linkActive : ''}`}
            style={{ color: 'var(--color-text)' }}
          >
            کالکشن شیرینی‌ها
          </NavLink>
          <span className={s.separator} aria-hidden />
          <NavLink to="/order/tracking" className={({ isActive }) => `${s.link} ${isActive ? s.linkActive : ''}`}>
            پیگیری سفارش
          </NavLink>
          <Link to="/cart" className={s.basket}>
            <Icon src="icons/shopping-bag.svg" size={17} />
            سبد خرید ({faNumber(count)})
          </Link>
        </div>
      </nav>
      <div className={s.baseline} aria-hidden />
    </header>
  );
}
